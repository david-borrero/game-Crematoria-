#include "Player.hh"
#include <vector>
#include <set>
#include <map>
#include <queue>


/**
 * Write the name of your player and save this file
 * with the same name and .cc extension.
 */
#define PLAYER_NAME dborrero



// random 


struct PLAYER_NAME : public Player {

    /**
     * Factory: returns a new instance of this class.
     * Do not modify this function.
     */
    static Player* factory () {
        return new PLAYER_NAME;
    }

    /**
     * Types and attributes for your player can be defined here.
     */

    
    int pioners_a_dalt = 0;
    int pioneers_totals = 0;

    set<Pos> Fur;
    set<Pos> Hell;
    set<Pos> Nec;

    vector<int> H;
    vector<int> N;

    int sol1, sol2;

    //PIONEERS A DALT

    bool arribo(vector<Pos>& v) 
    {
        int dist_sol = abs((v[0].j - sol2 + 2)/2);
        int dist = v.size();
        return dist < dist_sol;
    }


    vector<Pos> bfs_elevator(const Pos& pos_inicial) {
        queue<Pos> Q;
        map<Pos, Pos> haVingut; //Per seguir el camí
        vector< vector<bool> > enc(rows(), vector<bool>(cols(), false));

        Q.push(pos_inicial);
        enc[pos_inicial.i][pos_inicial.j] = true;

        while (!Q.empty()) {
            Pos pos_actual = Q.front();
            Q.pop();

            if (cell(pos_actual).type == Elevator and pos_actual != pos_inicial) {
                vector<Pos> path;
                while (pos_actual != pos_inicial) {
                    path.push_back(pos_actual);
                    pos_actual = haVingut[pos_actual];
                }
                path.push_back(pos_inicial);
                return path;
            }

            for (int i = 0; i < 8; ++i) {
                Pos nova = pos_actual + Dir(i);
                if (pos_ok(nova) and enc[nova.i][nova.j] == false and cell(nova).id == -1) {
                    Q.push(nova);
                    enc[nova.i][nova.j] = true;
                    haVingut[nova] = pos_actual;
                }
            }
        }

        // Si no es pot arribar al destí, retornar un vector buit
        return vector<Pos>();
    }

    vector<Pos> bfs_gema(const Pos& pos_inicial) {
        queue<Pos> Q;
        map<Pos, Pos> haVingut; //Per seguir camí
        vector< vector<bool> > enc(40, vector<bool>(80));

        Q.push(pos_inicial);
        enc[pos_inicial.i][pos_inicial.j] = true;

        while (!Q.empty()) {
            Pos pos_actual = Q.front();
            Q.pop();

            if (cell(pos_actual).gem and cell(pos_actual).id == -1) {
                vector<Pos> path;
                while (pos_actual != pos_inicial) {
                    path.push_back(pos_actual);
                    pos_actual = haVingut[pos_actual];
                }
                path.push_back(pos_inicial);
                return path;
            }

            for (int i = 0; i < 8; ++i) {
                Pos nova = pos_actual + Dir(i);
                if (pos_ok(nova) and enc[nova.i][nova.j] == false and cell(nova).id == -1) {
                    Q.push(nova);
                    enc[nova.i][nova.j] = true;
                    haVingut[nova] = pos_actual;
                }
            }
        }

        // Si no es pot arribar al destí, retornar un vector buit
        return vector<Pos>();
    }

    //PIONEERS A BAIX

    void furyan_a_prop(Pos& p)
    {
        for (int i = 0; i < 8; ++i) {
            Pos nova = p + Dir(i); 
            if (pos_ok(nova)) {
                Cell c = cell(nova);
                if (c.type == Cave or c.type == Elevator) { //Cal mirar si ascensor ja que hi pot haver un furyan
                    int id = c.id;
                    if (id != -1 and unit(id).player != me() and unit(id).type == Furyan) {
                        Fur.insert(nova);
                        for (int i = 0; i < 8; ++i) {
                            Pos n = nova + Dir(i);
                            Fur.insert(n);
                        }
                    }
                }
            } 
        }
    }

    Dir pos_segura(const Pos& p) {
        vector<Dir> v;
        for (int i = 0; i < 8; ++i) {
            Pos seg = p + Dir(i);
            if (pos_ok(seg) and cell(seg).type != Rock and cell(seg).id == -1 and Fur.find(seg) == Fur.end() and Hell.find(seg) == Hell.end()) {
                if (cell(seg).owner != me()) return Dir(i);
                else v.push_back(Dir(i));
            }
        }

        if (v.size() != 0) {
            int i = random(0, v.size()-1);
            return v[i];
        }

        return None;
    }

    vector<Pos> bfs_cell_blanca(const Pos& pos_inicial) {
        queue<Pos> Q;
        map<Pos, Pos> haVingut;
        vector< vector<bool> > enc(40, vector<bool>(80));

        Q.push(pos_inicial);
        enc[pos_inicial.i][pos_inicial.j] = true;

        while (!Q.empty()) {
            Pos pos_actual = Q.front();
            Q.pop();

            if (cell(pos_actual).owner != me() and cell(pos_actual).type != Elevator) {
                vector<Pos> path;
                while (pos_actual != pos_inicial) {
                    path.push_back(pos_actual);
                    pos_actual = haVingut[pos_actual];
                }
                path.push_back(pos_inicial);
                return path;
            }

            for (int i = 0; i < 8; ++i) {
                Pos nova = pos_actual + Dir(i);
                if (pos_ok(nova) and enc[nova.i][nova.j] == false) {
                    if (cell(nova).type != Rock and cell(nova).id == -1 and Hell.find(nova) == Hell.end())  {
                        Q.push(nova);
                        enc[nova.i][nova.j] = true;
                        haVingut[nova] = pos_actual;
                    }
                }
            }
        }

        // Si no es pot arribar al destí, retornar un vector buit
        return vector<Pos>();
    }


    //Trobar la millor cell possible per anar tenint en compte els enemics i les cells buides
    void trobar_cell(int id)
    {
        Pos p = unit(id).pos;
        vector<Pos> cell_buida = bfs_cell_blanca(p);

        if (cell_buida.size() > 1) {
            for (int i = 0; i < 8; ++i) {
                Pos seg = p + Dir(i);
                if (seg == cell_buida[cell_buida.size() - 2]) {
                    command(id, Dir(i));
                    return;
                }
            }
        }

        command(id, Dir(random(1, 7)));
    }

    void mourePioneers() 
    {
        vector<int> P = pioneers(me());

        pioners_a_dalt = 0;
        pioneers_totals = 0;

        for (const int id : P) {
            Pos p = unit(id).pos;
            if (p.k == 1) ++pioners_a_dalt;
            ++pioneers_totals;
        }

        for (const int id : P) {
            Pos p = unit(id).pos;
            if (p.k == 0) {
                Pos p_sobre(p.i, p.j, 1);
                vector<Pos> pos_gema = bfs_gema(p_sobre);
                if (cell(p).type == Elevator and not daylight(p_sobre) and pos_gema.size() != 0 and arribo(pos_gema)) {
                    command(id, Up);
                    continue;
                }
                
                Fur.clear();
                furyan_a_prop(p);
                if (Fur.find(p) != Fur.end() or Hell.find(p) != Hell.end()) {
                    Dir segura = pos_segura(p);
                    if (segura != None) {
                        command(id, segura);
                        continue;
                    }
                }

                bool fet = false;
                if (not daylight(p_sobre)) {
                    for (int i = 0; i < 8; ++i) {
                        Pos seg = p + Dir(i);
                        if (cell(seg).type == Elevator and cell(seg).id == -1 and Hell.find(seg) == Hell.end()) {
                            command(id, Dir(i));
                            fet = true;
                            continue;
                        }
                    }
                }
                if (fet) continue;

                //Trobar la cell buida més a prop
                trobar_cell(id);
            }
            else {
                vector<Pos> pos_gema = bfs_gema(p);
                if (pos_gema.size() != 0 and arribo(pos_gema)) {
                    for (int i = 0; i < 8; ++i) {
                        Pos seg = p + Dir(i);
                        if (seg == pos_gema[pos_gema.size() - 2]) {
                            command(id, Dir(i));
                            continue;
                        }
                    }
                    continue;
                }

                if (cell(p).type == Elevator) {
                    command(id, Down);
                    continue;
                }

                vector<Pos> pos_elevator = bfs_elevator(p);
                if (pos_elevator.size() != 0) {
                    for (int i = 0; i < 8; ++i) {
                        Pos seg = p + Dir(i);
                        if (seg == pos_elevator[pos_elevator.size() - 2]) {
                            command(id, Dir(i));
                            continue;
                        }
                    }
                    continue;
                } 

                command(id, Dir(random(1, 3)));
            }
        }
    }


    // FURYANS

    vector<Pos> bfs_enemic(const Pos& pos_inicial) {
        queue<Pos> Q;
        map<Pos, Pos> haVingut;
        vector< vector<bool> > enc(40, vector<bool>(80));

        Q.push(pos_inicial);
        enc[pos_inicial.i][pos_inicial.j] = true;

        while (!Q.empty()) {
            Pos pos_actual = Q.front();
            Q.pop();

            if (cell(pos_actual).id != -1 and unit(cell(pos_actual).id).player != me() and Hell.find(pos_actual) == Hell.end()) {
                vector<Pos> path;
                while (pos_actual != pos_inicial) {
                    path.push_back(pos_actual);
                    pos_actual = haVingut[pos_actual];
                }
                path.push_back(pos_inicial);
                return path;
            }

            for (int i = 0; i < 8; ++i) {
                Pos nova = pos_actual + Dir(i);
                if (pos_ok(nova) and enc[nova.i][nova.j] == false and Hell.find(nova) == Hell.end() and cell(nova).type != Rock) {
                    Q.push(nova);
                    enc[nova.i][nova.j] = true;
                    haVingut[nova] = pos_actual;
                }
            }
        }

        return vector<Pos>();
    }

    void moureFuryans() 
    {
        vector<int> F = furyans(me());
        for (const int id : F) {
            Pos p = unit(id).pos;

            if (Hell.find(p) != Hell.end()) {
                Dir segura = pos_segura(p);
                if (segura != None) {
                    command(id, segura);
                    continue;
                }
            }

            vector<Pos> dir_enemic = bfs_enemic(p);
            if (dir_enemic.size() > 1) {
                for (int i = 0; i < 8; ++i) {
                    Pos seg = p + Dir(i);
                    if (seg == dir_enemic[dir_enemic.size() - 2]) {
                        command(id, Dir(i));
                        continue;
                    }
                }
            }
        }
    }

    void area_hell()
    {   
        Hell.clear();
        for (int id : H) {
            Pos p = unit(id).pos;
            Hell.insert(p);
            for (int i = 0; i < 8; ++i) {
                Pos n = p + Dir(i);
                if (pos_ok(n) and cell(n).type != Rock) {
                    Hell.insert(n);
                    for (int i = 0; i < 8; ++i) {
                        Pos q = n + Dir(i);
                        if (pos_ok(q) and cell(q).type != Rock) Hell.insert(q);
                    }
                }
            }
        }
    }

    virtual void play () 
    {   
        pioneers_totals = 0;
        sol1 = (40+round()*2)%80; // primer extrem del sol
        sol2 = (80+round()*2)%80; // ultim extrem del sol
        H = hellhounds();
        area_hell();
        mourePioneers();
        moureFuryans();
    }

};


/**
 * Do not modify the following line.
 */
RegisterPlayer(PLAYER_NAME);