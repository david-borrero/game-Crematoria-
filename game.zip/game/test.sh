#!/bin/bash

i=1
while [ $i -le $1 ]
do
  echo $i
  ./Game dborrero29 Marcus SterrySX4 APV23_P10 -i default.cnf -o output/default-auto-$i.res -s "$i" 2> >(grep "score")
  ((++i))
done